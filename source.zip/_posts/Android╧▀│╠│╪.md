---
title: Android线程池
date: 2017-09-01 13:27:30
tags: Android
---
### 线程池
Android中的线程池来自Java的Executor,是一个接口，真正的实现为ThreadPoolExecutor,它的构造方法中需要配置一些参数，不同参数可以实现不同的线程池。Android在工厂Executors中提供了四种不同的线程池，都是通过配置ThreadPoolExecutor的参数实现的。
- 重用线程池中的线程，减小多次创建、回收线程带来的开销
- 控制线程数量，减小因竞争资源发生死锁的概率
- 对线程进行管理

### ThreadPoolExecutor
```
    public ThreadPoolExecutor(int corePoolSize,
                              int maximumPoolSize,
                              long keepAliveTime,
                              TimeUnit unit,
                              BlockingQueue<Runnable> workQueue) {
        this(corePoolSize, maximumPoolSize, keepAliveTime, unit, workQueue,
             Executors.defaultThreadFactory(), defaultHandler);
    }
```
- corePoolSize：核心线程数，默认情况下，核心线程会一直存活，若设置allowCoreThreadTimeOut为true，则核心线程超时也会被回收
- maximumPoolSize：最大线程数，等于核心线程数+非核心线程数
- keepAliveTime：线程的空闲时存活时间，超时就回收，默认情况下对核心线程无效
- unit：keepAliveTime的单位
- workQueue：当前使用线程数超过核心线程，存入工作队列

**运行规则：**
- 当线程池中线程数量未超过核心线程数量，新来的任务会直接交给一闲置的核心线程
- 线程数量未超过核心线程时，放入workQueue工作队列
- 工作队列满后，开启非核心线程进行处理
- 线程数量大于最大线程数后拒绝执行

### 线程池的分类
**1.FixedThreadPool**
```
    public static ExecutorService newFixedThreadPool(int nThreads) {
        return new ThreadPoolExecutor(nThreads, nThreads,
                                      0L, TimeUnit.MILLISECONDS,
                                      new LinkedBlockingQueue<Runnable>());
    }
```
线程池只有nThreads个核心线程，未超过核心线程数量时直接交付，超过进入队列等待，不回收核心线程。
**2.SingleThreadExecutor**
```
    public static ExecutorService newSingleThreadExecutor() {
        return new FinalizableDelegatedExecutorService
            (new ThreadPoolExecutor(1, 1,
                                    0L, TimeUnit.MILLISECONDS,
                                    new LinkedBlockingQueue<Runnable>()));
    }
```
线程池中只有一个核心线程，未超过1时直接交付，超过进入队列等待，不回收核心线程。
**3.CachedThreadPool**
```
    public static ExecutorService newCachedThreadPool() {
        return new ThreadPoolExecutor(0, Integer.MAX_VALUE,
                                      60L, TimeUnit.SECONDS,
                                      new SynchronousQueue<Runnable>());
    }
```
线程池中无核心线程，可以有无限多非核心线程。当任务来时，若无空闲线程则创建非核心线程，有空闲线程则复用，空闲超过60秒将回收。
**4.ScheduledThreadPoolExecutor **
```
     public ScheduledThreadPoolExecutor(int corePoolSize) {
         super(corePoolSize, Integer.MAX_VALUE, 0, TimeUnit.NANOSECONDS,
               new DelayedWorkQueue());
     }
```
线程池中有corePoolSize个核心线程，可以有无限多非核心线程。当任务来时，未超过核心线程数量时直接交付，超过则放入延时队列，实现定时任务和延时任务，非核心线程空闲立即被回收。
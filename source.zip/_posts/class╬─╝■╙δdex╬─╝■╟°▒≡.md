---
title: class与dex区别
date: 2017-11-03 23:03:02
tags: Java虚拟机
---
### Java、Class、 dex、 apk文件区别
Java：应用程序的源文件
Class:Java等语言经过javac编译后生成的字节码，可被Java虚拟机执行
dex:Class文件经过dex编译后生成的文件，被Davlik虚拟机执行
apk:包含dex文件及资源文件

### Class文件结构
![](http://img.blog.csdn.net/20131230204449140)
**magic:** 值为0xCAFEBABE，标志该文件为可被执行的java字节码
**minor_version:** class文件次版本
**major_version:** class文件住版本，与次版本一起确定class文件对应的jdk版本
**contast_pool_count、contast_pool:** 常量区，存放字面量、符号引用
**access_flag:** 标志类或接口的访问权限，如public abstract enum final 等
**this_class、super_class:** 类索引、超类索引
**interfact_count、interfaces:** 当前类的直接超类的数量、接口表
**fileds_count、fields:** 类中类变量和实例变量
**methods_count、methods:** 类中方法
**attributes_count、attributes:** 记录文件中定义的类和接口等

### dex文件结构
![](http://images2015.cnblogs.com/blog/855014/201611/855014-20161106141434190-271756210.png)
由于dex文件庞大，目前只了解到一个dex文件就记录了所有类的信息

### Class与dex的区别
![](http://img.blog.csdn.net/20140324203743562)
1.虚拟机 class用jvm执行，dex用dvm执行
2.文件 class中冗余信息多，dex会去除冗余信息，包含所有类，查找方便，适合手机端

### JVM与DVM
1.JVM基于栈（使用栈帧，内存），DVM基于寄存器，速度更快，适合手机端
2.JVM执行Class字节码，DVM执行DEX
3.JVM只能有一个实例，一个应用启动运行在一个DVM

### DVM与ART
DVM：每次运行应用都需要一次编译，效率降低
ART：Android5.0以上默认为ART，系统会在程序安装后进行一次预编译，将代码转为机器语言存在本地，这样在每次运行时不用再进行编译，提高启动效率；
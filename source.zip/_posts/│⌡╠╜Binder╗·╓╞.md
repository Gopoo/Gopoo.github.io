---
title: 初探Binder机制
date: 2017-11-04 19:15:45
tags: Android
---
### 前言
看了很多Binder通信机制的博客，一直搞不懂，讲的很复杂，看过[《简单明了，彻底地理解Binder》](http://www.jianshu.com/p/04a034cbbc27)后，大概明白了一些，但是感觉还是不容易理解
### Binder的C/S架构
![](http://upload-images.jianshu.io/upload_images/2154124-746b33a4cfad1b93.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
这张图描述了Binder基本流程，服务端注册服务，客户端查找到服务后开始请求

### Binder 原理
![](http://upload-images.jianshu.io/upload_images/2154124-8788ce62c0c7384e.png?imageMogr2/auto-orient/strip%7CimageView2/2/w/1240)
*上面了解了基本流程，这里介绍凭什么么能跨进程通信*
**1.注册服务**：Server通过Binder驱动在ServiceManger中注册，在Manger中存放名称及Binder的引用（类似DNS）
**2.查询服务：**Client通过Binder驱动在ServiceManger中根据指定的名称查找Binder的引用
**3.使用服务：**Client获取到Binder引用后，调用其方法（即开始进程间通信，此时客户端线程被挂起），Client将数据写入到Parcel中，调用`transact()`函数将数据放入Binder共享内存区，Binder驱动将Client的数据复制到远程进程的共享内存，并调用远程进程执行`onTransact()`函数。远程端执行后将数据放入远程端与Binder驱动的共享内存，Binder驱动将返回结果复制到Client与Binder驱动的共享内存区（唤起客户端线程）
### 简单的Binder机制运用
```
//获取WindowManager服务引用
WindowManager wm = (WindowManager)getSystemService(getApplication().WINDOW_SERVICE);  
//布局参数layoutParams相关设置略...
View view=LayoutInflater.from(getApplication()).inflate(R.layout.float_layout, null);  
//添加view
wm.addView(view, layoutParams);
```
1.通过Binder驱动在ServiceManger中查找名称为`getApplication().WINDOW_SERVICE`的服务
2.加载view
3.将view、params放入Activity与Binder驱动的共享内存
4.Binder驱动将其拷贝到远程端与Binder驱动的共享内存
5.调用addView方法，添加view

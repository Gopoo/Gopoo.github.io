---
title: Android动画
date: 2017-07-13 22:45:45
tags: Android
---
## Android 动画分类
1. 补间动画（TweenedAnimation）:改变View的绘制区域，不改变本身的属性
2. 逐帧动画（FrameAnimation）：多张图片按顺序播放，易造成OOM
3. 属性动画（PropetryAnimation）：改变任意对象（包括View）的属性

## 补间动画
补间动画共有四种 scale、rotate、translate、alpha（缩放、旋转、平移、透明度）,anim文件夹

```
<!--以当前View中心（50%，50%）为原点从0开始放大两倍,一直循环此动画，匀速插值器-->
<scale
	android:interpolator="@android:anim/linear_interpolator"
	android:repeatType="restart"
	android:repeatCount="-1"
	android:fromXScale="0"
    android:fromYScale="0"
    android:toXScale="2"
    android:toYScale="2"
    android:pivotY="50%"
    android:pivotX="50%"
     >
</scale>
<!--以当前View中心（50%，50%）为原点开始旋转2次-->
<rotate xmlns:android="http://schemas.android.com/apk/res/android"
    android:fromDegrees="0"
    android:repeatType="restart"
	android:repeatCount="1"
    android:toDegrees="359"
    android:interpolator="@android:anim/linear_interpolator"
    android:pivotX="50%"
    android:pivotY="50%"
    android:duration="2000"
    >
</rotate>
<!--从(0,0)平移到(200,400)，平移一次-->
<translate
    android:interpolator = "@android:anim/accelerate_decelerate_interpolator"
    android:repeatType="restart"
	android:repeatCount="0"
    android:fromXDelta="0" 
    android:fromYDelta="0" 
    android:toXDelta="200" 
    android:toYDelta="400" 
    android:duration = "600"
    >
</translate>

<!--从暗（不显示）到亮（显示），再从亮（显示）到暗（不显示-->
<alpha
	android:repeatCount="1"
	android:repeatType="reverse"
    android:fromAlpha="0f"
    android:toAlpha="1.0f"
    android:duration="3000"
    >

</alpha>

<!--放入set标签可同时实现多个动画-->
```
```
Animation animation = AnimationUtils.loadAnimation(this,R.anim.text_anim);
anim_tv.startAnimation(animation);
```


## 逐帧动画
类似电影,drawable文件夹

```
<!--named:anim,contain:3 images-->
<?xml version="1.0" encoding="utf-8"?>
<animation-list xmlns:android="http://schemas.android.com/apk/res/android">
    <item android:drawable="@drawable/frame3" android:duration="100"></item>
    <item android:drawable="@drawable/frame2" android:duration="100"></item>
    <item android:drawable="@drawable/frame1" android:duration="100"></item>
</animation-list>

```

```
imageview.setImageResource(R.drawable.anim);
AnimationDrawable drawable = (AnimationDrawable) anim_iv.getDrawable();
drawable.start();
```

## 属性动画
改变属性，animator文件夹

### ValueAnimator
改变值的大小
```
		//1000ms后开始匀速从0增到99999999
        ValueAnimator valueAnimator =ValueAnimator.ofInt( 0,99999999 );
        valueAnimator.setDuration(4000);
        valueAnimator.setStartDelay(1000);
        valueAnimator.setInterpolator(new LinearInterpolator());
        valueAnimator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                int money= (int) animation.getAnimatedValue();
                second.setText(money+"元");
            }
        });
```

### ObjectAnimator

```
    <!--重复 向右平移200，返回-->
    <objectAnimator
        android:propertyName="translationX"
        android:duration="5000"
        android:valueFrom="0"
        android:valueTo="200"
        android:valueType="floatType"
        android:repeatCount="-1"
        android:repeatMode="reverse">
    </objectAnimator>
```
```
        Animator animator =  AnimatorInflater.loadAnimator(this,R.animator.second);
        animator.setTarget(button);
        animator.start();
```

